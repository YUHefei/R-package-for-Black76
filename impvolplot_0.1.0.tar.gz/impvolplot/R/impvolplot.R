#install.packages('plotly')
#library(plotly)
#' Function to calculate option price by Black's forumla
#'
#' @param x strike price
#' @param r risk free rate
#' @param sigma volatility
#' @param type Put or Call
#' @param T time to maturity
#' @param F futures price
#' @return a value
#' @export
#' @examples
#'
#' black(100,103,0.5,0.06,0.11,"C")
black<-function(F, x, T, r, sigma, type="C"){
  d1 <- (log(F/x) + (sigma^2/2)*T) / (sigma*sqrt(T))
  d2 <- d1 - sigma*sqrt(T)
  if(type=="C"){
    price<- (F*pnorm(d1) - x*pnorm(d2)) *exp(-r*T)
  }
  if(type=="P"){
    price <- exp(-r*T)*(x*pnorm(-d2) - F*pnorm(-d1))
  }
  return(price)
}

#' Bisection Method to find implied volatility
#'
#' @param x strike price
#' @param r risk free rate
#' @param spot spot price of option
#' @param type Put or call
#' @param F Future Price
#' @param= volatility
#' @return a value
#' @export
#' @examples
#'
#' black76_vol(100,103,0.5,0.06,1.817968,"C")
black76_vol<-function(F, x, T, r, spot, type){
  sigma <- 0.20
  sigma_high <- 1
  sigma_low <- 0.001
  count <- 0 ## counter for iterations
  error <- black(F, x, T, r, sigma, type) - spot

 while(abs(error) > 0.000001 && count<100000){
    if(error < 0){
      sigma_low <- sigma
      sigma <- (sigma_high + sigma)/2
      #print(c(sigma_low,sigma,sigma_high))
    }else{
      sigma_high <- sigma
      sigma <- (sigma_low + sigma)/2
      #print(c(sigma_low,sigma,sigma_high))
    }
    error <- black(F, x, T, r, sigma, type) - spot
    count <- count + 1
  }

  if(count==100000){
    return("Value did not converge")
  }else{
    return(sigma)
  }
}
strike=0
optionPrice=1
futurePrice=2
time_to_expiry=3

##' The function to plot implied volatility versus multiple variables.
#' input a data frame as follows df<-data.frame(strike=c(50,20,51,52),type=c("C","P","C","P"),optionPrice=c(1.62,0.01,1.65,0.08),futurePrice=c(48.03,48.03,48.03,48.03),time_to_expiry=c(0.1423,0.1423,0.1423,0.1423))
#' the risk free rate can also be an input. Enter the yearly continuously compounded rate in decimal points
#'
#' @param df input dataframe
#' @param rate risk free rate
#' @param x x axis
#' @param y y axis
#' @return a list of implied volitality and a 3D interactive plot
#' @export
#' @examples
#'
#' df<-data.frame(strike=c(50,20,51,52),type=c("C","P","C","P"),optionPrice=c(1.62,0.01,1.65,0.08),futurePrice=c(48.03,48.03,48.03,48.03),time_to_expiry=c(0.1423,0.1423,0.1423,0.1423))
#' plotimpliedVol(df)
#' plotimpliedVol(df, rate=0.04, x = strike, y = futurePrice)


plotimpliedVol<-function(df,rate=0.03, x = strike, y = optionPrice)
{
  vol<-rep(0, nrow(df))
  strike=0
  optionPrice=1
  futurePrice=2
  time_to_expiry=3
  for (i in 1:nrow(df))
  {
    vol[i]<-black76_vol(df$futurePrice[i],df$strike[i],df$time_to_expiry[i],rate,df$optionPrice[i],df$type[i])
  }

  df$Volitality=vol
  df_2 <- df[ !grepl(paste('Value did not converge', collapse="|"), df$Volitality),]

  df_2$type <- as.character (df_2$type)
  df_2$type[which(df_2$type == "P")] <- 'Put Option'
  df_2$type[which(df_2$type == "C")] <- 'Call Option'
  colnames(df_2) <- c("Strike_Price", "type","Option_Price","Future_Price","Time_to_Expiry","Volitality")
  df_2$Volitality <- as.numeric(df_2$Volitality)
  df_2$type <- as.factor(df_2$type)

  if (x==0 & y==1){p<-plotly::plot_ly(df_2, x =~ Strike_Price,
                              y =~ Option_Price,
                              z =~ Volitality,
                              color = ~type,
                              mode="markers",
                              text =~paste('Future Price: ', Future_Price,
                                           '<br> Time to Expiry: ', Time_to_Expiry))
  }else if (x==0 & y==2) {p<-plotly::plot_ly(df_2, x =~ Strike_Price,
                                     y =~ Future_Price,
                                     z =~ Volitality,
                                     color = ~type,
                                     mode="markers",
                                     text =~paste('Option Price: ', Option_Price,
                                                  '<br> Time to Expiry: ', Time_to_Expiry))
  }else if (x==0 & y==3) {p<-plotly::plot_ly(df_2, x =~ Strike_Price,
                                     y =~ Time_to_Expiry,
                                     z =~ Volitality,
                                     color = ~type,
                                     mode="markers",
                                     text =~paste('Option Price: ', Option_Price,
                                                  '<br> Future Price: ', Future_Price))
  }else if (x==1 & y==2) {p<-plotly::plot_ly(df_2, x =~ Option_Price,
                                     y =~ Future_Price,
                                     z =~ Volitality,
                                     color = ~type,
                                     mode="markers",
                                     text =~paste('Strike Price: ', Strike_Price,
                                                  '<br> Time to Expiry: ', Time_to_Expiry))
  }else if (x==1 & y==3) {p<-plotly::plot_ly(df_2, x =~ Option_Price,
                                     y =~ Time_to_Expiry,
                                     z =~ Volitality,
                                     color = ~type,
                                     mode="markers",
                                     text =~paste('Future Price: ', Future_Price,
                                                  '<br> Strike Price: ', Strike_Price))
  }else if (x==2 & y==3) {p<-plotly::plot_ly(df_2, x =~ Future_Price,
                                     y =~ Time_to_Expiry,
                                     z =~ Volitality,
                                     color = ~type,
                                     mode="markers",
                                     text =~paste('Option Price: ', Option_Price,
                                                  '<br> Strike Price: ', Strike_Price))
  }


  l<-df
  return(list(l,p))
}


